# permainan-kartu
Halo, cara run file html:
1. Download ZIP
2. Extract
3. Buka file HTML di browser kalian :D
